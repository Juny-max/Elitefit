<?php
session_start();
include_once __DIR__ . "/../config.php";

// Redirect if not logged in as equipment manager
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'equipment_manager') {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get equipment list
$equipment_sql = "SELECT * FROM equipment ORDER BY name";
$equipment_result = $conn->query($equipment_sql);
$equipment = $equipment_result->fetch_all(MYSQLI_ASSOC);

// Handle equipment status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $equipment_id = $_POST['equipment_id'];
    $status = $_POST['status'];
    $maintenance_date = !empty($_POST['maintenance_date']) ? $_POST['maintenance_date'] : null;
    
    $update_sql = "UPDATE equipment SET status = ?, last_maintenance_date = ? WHERE equipment_id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssi", $status, $maintenance_date, $equipment_id);
    
    if ($stmt->execute()) {
        $success = "Equipment status updated successfully!";
        // Refresh equipment list
        header("Location: equipment_manager_dashboard.php?success=" . urlencode($success));
        exit();
    } else {
        $error = "Error updating equipment: " . $conn->error;
    }
}

// Handle new equipment addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_equipment'])) {
    $name = trim($_POST['name']);
    $status = $_POST['status'];
    $maintenance_date = !empty($_POST['maintenance_date']) ? $_POST['maintenance_date'] : null;
    
    $insert_sql = "INSERT INTO equipment (name, status, last_maintenance_date) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("sss", $name, $status, $maintenance_date);
    
    if ($stmt->execute()) {
        $success = "New equipment added successfully!";
        // Refresh equipment list
        header("Location: equipment_manager_dashboard.php?success=" . urlencode($success));
        exit();
    } else {
        $error = "Error adding equipment: " . $conn->error;
    }
}

// Handle equipment deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_equipment'])) {
    $equipment_id = $_POST['equipment_id'];
    
    $delete_sql = "DELETE FROM equipment WHERE equipment_id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $equipment_id);
    
    if ($stmt->execute()) {
        $success = "Equipment deleted successfully!";
        // Refresh equipment list
        header("Location: equipment_manager_dashboard.php?success=" . urlencode($success));
        exit();
    } else {
        $error = "Error deleting equipment: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipment Manager Dashboard - EliteFit Gym</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Poppins', sans-serif;
        }
        .dashboard-header {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .status-available {
            color: #28a745;
        }
        .status-maintenance {
            color: #ffc107;
        }
        .status-out_of_service {
            color: #dc3545;
        }
        .badge {
            font-size: 0.9rem;
            padding: 5px 10px;
        }
        .action-btn {
            margin-right: 5px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .sidebar {
            background-color: #343a40 !important;
        }
        .nav-link {
            color: rgba(255, 255, 255, 0.75);
        }
        .nav-link:hover, .nav-link.active {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .sidebar .nav-item {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-flex flex-column bg-dark sidebar" style="min-height: 100vh;">
                <div class="flex-grow-1">
                    <div class="position-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active text-white" href="equipment_manager_dashboard.php">
                                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <!-- Logout Button at Bottom -->
                <div class="mt-auto p-3">
                    <a href="../logout.php" class="btn btn-light w-100">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="dashboard-header mt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h2><i class="fas fa-dumbbell me-2"></i>Equipment Manager Dashboard</h2>
                        <a href="../logout.php" class="btn btn-light">
                            <i class="fas fa-sign-out-alt me-1"></i> Logout
                        </a>
                    </div>
                </div>

                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($_GET['success']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= htmlspecialchars($error) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Equipment Management Section -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="fas fa-dumbbell me-2"></i>Equipment Management</h4>
                    </div>
                    <div class="card-body">
                        <!-- Add New Equipment Form -->
                        <div class="mb-4">
                            <h5>Add New Equipment</h5>
                            <form method="POST" class="row g-3">
                                <div class="col-md-4">
                                    <label for="name" class="form-label">Equipment Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="col-md-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="available">Available</option>
                                        <option value="maintenance">Maintenance</option>
                                        <option value="out_of_service">Out of Service</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="maintenance_date" class="form-label">Last Maintenance Date</label>
                                    <input type="date" class="form-control" id="maintenance_date" name="maintenance_date">
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <button type="submit" name="add_equipment" class="btn btn-success w-100">
                                        <i class="fas fa-plus me-1"></i> Add
                                    </button>
                                </div>
                            </form>
                        </div>

                        <!-- Equipment List -->
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Equipment Name</th>
                                        <th>Status</th>
                                        <th>Last Maintenance</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($equipment as $item): ?>
                                        <tr>
                                            <td><?= $item['equipment_id'] ?></td>
                                            <td><?= htmlspecialchars($item['name']) ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $item['status'] == 'available' ? 'success' : 
                                                    ($item['status'] == 'maintenance' ? 'warning' : 'danger') 
                                                ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $item['status'])) ?>
                                                </span>
                                            </td>
                                            <td><?= $item['last_maintenance_date'] ? date('M j, Y', strtotime($item['last_maintenance_date'])) : 'N/A' ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary action-btn" data-bs-toggle="modal" data-bs-target="#editModal<?= $item['equipment_id'] ?>">
                                                    <i class="fas fa-edit"></i> Edit
                                                </button>
                                                <button class="btn btn-sm btn-danger action-btn" data-bs-toggle="modal" data-bs-target="#deleteModal<?= $item['equipment_id'] ?>">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </td>
                                        </tr>

                                        <!-- Edit Modal -->
                                        <div class="modal fade" id="editModal<?= $item['equipment_id'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $item['equipment_id'] ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="editModalLabel<?= $item['equipment_id'] ?>">Edit Equipment</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="equipment_id" value="<?= $item['equipment_id'] ?>">
                                                            <div class="mb-3">
                                                                <label for="edit_name<?= $item['equipment_id'] ?>" class="form-label">Equipment Name</label>
                                                                <input type="text" class="form-control" id="edit_name<?= $item['equipment_id'] ?>" 
                                                                       name="name" value="<?= htmlspecialchars($item['name']) ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="edit_status<?= $item['equipment_id'] ?>" class="form-label">Status</label>
                                                                <select class="form-select" id="edit_status<?= $item['equipment_id'] ?>" name="status" required>
                                                                    <option value="available" <?= $item['status'] == 'available' ? 'selected' : '' ?>>Available</option>
                                                                    <option value="maintenance" <?= $item['status'] == 'maintenance' ? 'selected' : '' ?>>Maintenance</option>
                                                                    <option value="out_of_service" <?= $item['status'] == 'out_of_service' ? 'selected' : '' ?>>Out of Service</option>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="edit_maintenance_date<?= $item['equipment_id'] ?>" class="form-label">Last Maintenance Date</label>
                                                                <input type="date" class="form-control" id="edit_maintenance_date<?= $item['equipment_id'] ?>" 
                                                                       name="maintenance_date" value="<?= $item['last_maintenance_date'] ?>">
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" name="update_status" class="btn btn-primary">Save Changes</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Delete Confirmation Modal -->
                                        <div class="modal fade" id="deleteModal<?= $item['equipment_id'] ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?= $item['equipment_id'] ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-danger text-white">
                                                        <h5 class="modal-title" id="deleteModalLabel<?= $item['equipment_id'] ?>">Confirm Deletion</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form method="POST">
                                                        <div class="modal-body">
                                                            <input type="hidden" name="equipment_id" value="<?= $item['equipment_id'] ?>">
                                                            <p>Are you sure you want to delete the equipment "<strong><?= htmlspecialchars($item['name']) ?></strong>"?</p>
                                                            <p class="text-danger">This action cannot be undone.</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" name="delete_equipment" class="btn btn-danger">Delete Equipment</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
    </script>
</body>
</html>