-- Add password reset columns to users table
ALTER TABLE users
ADD COLUMN reset_token VARCHAR(255) DEFAULT NULL,
ADD COLUMN reset_expires DATETIME DEFAULT NULL;
